// OBJECT LITERAL

const salon = {
    name: "Paw Beans Pet Salon",
    phone: "5551234567",
    address:{
        street: "Paw Ave.",
        number: "1549 Suite F"
    },
    operatingHours:{
        days: "Mon-Fri",
        open: "9AM",
        close: "9PM"
    },
    pets:[],
    count:function(){
        alert("You are registered! " + this.pets.length + "pets have been registered.");
    }
}
// object destructor

let {name,phone,address:{street,number},operatingHours:{days,open,close}} = salon;

//display the information of the salon in HTML main

//create a div with ID to select element and display + use innerHTML
document.getElementById("opinfo").innerHTML= `<h2> Welcome to ${name}!</h2>
<p>Phone: ${phone}</p><p>Adress: ${number}, ${street}</p><p>Operating Hours: ${days}:${open}-${close}</p>`;

//create object contstructor
class Pet{
    constructor(name,age,gender,breed,service,oName,oPhone){
        this.name = name,
        this.age = age,
        this.gender = gender;
        this.breed = breed;
        this.service = service,
        this.oName = oName,
        this.oPhone = oPhone;

    }
    ownerInfo = function(){
        console.log(`${this.oName} ${this.oPhone}`);
    }
}
//create pets simple
const scooby = new Pet("Scoobs","25","Male","Dane","Full Service","Shaggy","1234567");
salon.pets.push(scooby);
displayList(scooby);
scooby.ownerInfo();

scooby.ownerInfo();
//create register function

let txtName = document.getElementById("petName");
let txtAge = document.getElementById("petAge");
let txtGender = document.getElementById("petGender");
let txtBreed = document.getElementById("breed");
let txtService = document.getElementById("petService");
let txtOwner = document.getElementById("ownerName");
let txtOwnerContact = document.getElementById("ownerContact");



function register(){

    let thePet = new Pet(txtName.value,txtAge.value,txtGender.value,txtBreed.value,txtService.value,txtOwner.value,txtOwnerContact.value);
    console.log(thePet);
    //take values from HTML form

    //create pet
salon.pets.push(thePet);
displayList(thePet);
    //display in HTML
    clear();
}
function displayList(aPet){
    let listBody = document.getElementById("pet-list");
    let item = `
    <li class="list-group-item">Pet Name: ${aPet.name}</li> <li class="list-group-item">Age: ${aPet.age}</li> <li class="list-group-item">Service: ${aPet.service}</li> <li class="list-group-item">Gender: ${aPet.gender}</li> <li class="list-group-item">Breed: ${aPet.breed}</li> <li class="list-group-item">Owner: ${aPet.oName}</li> <li class="list-group-item">Phone: ${aPet.oPhone}</li>`;
    listBody.innerHTML+=item;
    //mortal hq show all the pet's attributes on the list, apply CSS style
    //inmortal hw show all the pets in a table
}
const newLi = document.getElementById('pet-list');
newLi.setAttribute('class','list-group');


function clear(){
txtName.value = " "; 
txtAge.value =" ";
txtGender.value = " ";
txtBreed.value = " ";
txtService.value = " ";
txtOwner.value = " ";
txtOwnerContact.value = " ";
}